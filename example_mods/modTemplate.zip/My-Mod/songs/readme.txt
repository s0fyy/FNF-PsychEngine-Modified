Put your custom songs here
It should be a folder with your custom song's name, and inside of it should include two files: "Inst.ogg" and "Voices.ogg"
the Data folder has been moved to your song folder, inside the folder make a new folder called "Chart"
that's where all the Data files from before will go.